
// ReSharper disable once CheckNamespace
namespace ChargifyNET
{
    /// <summary>
    /// TODO
    /// </summary>
    public class IInvoicePaymentAndCredit
    {
    }
}